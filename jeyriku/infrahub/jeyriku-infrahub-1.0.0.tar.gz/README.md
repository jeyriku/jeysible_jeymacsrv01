# Ansible Collection - jeyriku.infrahub

Documentation for the collection.

Cette collection contient un squelette minimal pour fournir des plugins d'inventaire ou modules
permettant d'interroger une instance Infrahub (ex: `jeysrv10`).

Vous pouvez ajouter ici un plugin d'inventaire (dans `plugins/inventory/`) ou un module
(`plugins/modules/`) qui communique avec l'API d'Infrahub.

Exemple rapide : créer `plugins/inventory/infrahub.py` qui implémente l'API d'Ansible Inventory Plugin.
Voir la documentation Ansible pour l'API des plugins d'inventaire.
